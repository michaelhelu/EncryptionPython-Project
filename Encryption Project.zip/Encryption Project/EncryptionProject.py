# -------------------- ENCRYPTION AND DECRYPTION USING CAESAR CIPHER --------------------

# Function to encrypt text using Caesar Cipher
def encrypt(text, shift):
    encrypted_text = ""
    for char in text:
        if char.isalpha():  # Only shift alphabetic characters
            shift_base = 65 if char.isupper() else 97
            encrypted_text += chr((ord(char) + shift - shift_base) % 26 + shift_base)
        else:
            encrypted_text += char  # Non-alphabet characters remain unchanged
    return encrypted_text

# Function to decrypt text using Caesar Cipher
def decrypt(text, shift):
    return encrypt(text, -shift)  # Decryption is just the reverse of encryption

# Function to read a file and encrypt its content
def encrypt_file(input_file_path, output_file_path, shift):
    with open(input_file_path, 'r', encoding='utf-8') as f:
        text = f.read()

    encrypted_text = encrypt(text, shift)

    with open(output_file_path, 'w', encoding='utf-8') as f:
        f.write(encrypted_text)

    print(f"🔒 File encrypted and saved as {output_file_path}")

# Function to decrypt a file and save the result
def decrypt_file(input_file_path, output_file_path, shift):
    with open(input_file_path, 'r', encoding='utf-8') as f:
        encrypted_text = f.read()

    decrypted_text = decrypt(encrypted_text, shift)

    with open(output_file_path, 'w', encoding='utf-8') as f:
        f.write(decrypted_text)

    print(f"🔓 File decrypted and saved as {output_file_path}")


# -------------------- MAIN --------------------

if __name__ == "__main__":
    # File paths
    input_file_path = "input.txt"  # Replace with your input file path
    encrypted_file_path = "encrypted_file.txt"
    decrypted_file_path = "decrypted_file.txt"

    # Key (shift value for Caesar Cipher)
    shift = 3  # You can change this to any number

    # Encrypt the file
    encrypt_file(input_file_path, encrypted_file_path, shift)

    # Decrypt the file
    decrypt_file(encrypted_file_path, decrypted_file_path, shift)
